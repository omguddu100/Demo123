import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publishmodel-page',
  templateUrl: './publishmodel-page.component.html',
  styleUrls: ['./publishmodel-page.component.scss']
})
export class PublishmodelPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
