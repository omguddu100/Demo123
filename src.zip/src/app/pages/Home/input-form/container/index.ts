export * from '../components/reactive-form/reactive-form.component'
//export * from '../components/template-driven/template-driven.component'
export * from '../container/input-pages/input-pages.component'