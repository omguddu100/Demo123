import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-pages',
  templateUrl: './input-pages.component.html',
  styleUrls: ['./input-pages.component.scss']
})
export class InputPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
