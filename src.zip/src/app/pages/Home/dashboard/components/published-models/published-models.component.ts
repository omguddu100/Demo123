import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-published-models',
  templateUrl: './published-models.component.html',
  styleUrls: ['./published-models.component.scss']
})
export class PublishedModelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
