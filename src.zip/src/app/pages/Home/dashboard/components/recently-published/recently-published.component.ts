import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recently-published',
  templateUrl: './recently-published.component.html',
  styleUrls: ['./recently-published.component.scss']
})
export class RecentlyPublishedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
